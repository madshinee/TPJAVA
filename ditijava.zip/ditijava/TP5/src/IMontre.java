public interface IMontre {
    Montre saisie(); 
    void affichage(Montre m); 
}
