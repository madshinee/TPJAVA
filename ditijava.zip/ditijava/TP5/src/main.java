public class main {
    public static void main(String[] args) {
        ArticleImpl articleImpl = new ArticleImpl();
        Article article = articleImpl.saisie();
        articleImpl.affichage(article);
        System.out.println();
        ChemiseImpl chemiseImpl = new ChemiseImpl();
        Chemise chemise = chemiseImpl.saisie();
        chemiseImpl.affichage(chemise);
        System.out.println();
        MontreImpl montreImpl = new MontreImpl();
        Montre montre = montreImpl.saisie();
        montreImpl.affichage(montre);
    }
}