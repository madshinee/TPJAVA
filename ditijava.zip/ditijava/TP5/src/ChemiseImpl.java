import java.util.Scanner; 
public class ChemiseImpl implements IChemise {
    @Override
    public Chemise saisie() {
        Scanner scanner = new Scanner(System.in); 

        System.out.println("Entrer infos (chemise)01"
        		+ " :");
        System.out.print("ID : ");
        int id = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Libell� : ");
        String lib = scanner.nextLine();

        System.out.print("Type de couture : ");
        String couture = scanner.nextLine(); 

        return new Chemise(id, lib, couture);
    }

    @Override
    public void affichage(Chemise c) {
        System.out.println("********* CHEMISE *********");
        System.out.println("ID : " + c.getId());
        System.out.println("Libell� : " + c.getLib());
        System.out.println("Couture : " + c.getCouture());
    }
}