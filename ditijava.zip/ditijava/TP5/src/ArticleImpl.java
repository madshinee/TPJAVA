import java.util.Scanner; // Importez Scanner pour la saisie utilisateur

public class ArticleImpl implements IArticle {
    @Override
    public Article saisie() {
        Scanner scanner = new Scanner(System.in); 

        System.out.println("Entrer infos (article) :");
        System.out.print("ID : ");
        int id = scanner.nextInt(); 
        scanner.nextLine(); 

        System.out.print("Libell� : ");
        String lib = scanner.nextLine(); 

        return new Article(id, lib); 
    }

    @Override
    public void affichage(Article a) {
        System.out.println("********* ARCTICLE *********");
        System.out.println("ID : " + a.getId());
        System.out.println("Libell� : " + a.getLib());
    }
}
