import java.util.Scanner; 

public class MontreImpl implements IMontre {
    @Override
    public Montre saisie() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Entrer infos (montre) :");
        System.out.print("ID : ");
        int id = scanner.nextInt(); 
        scanner.nextLine(); 

        System.out.print("Libell� : ");
        String lib = scanner.nextLine(); 

        System.out.print("Nature : ");
        String nature = scanner.nextLine(); 

        return new Montre(id, lib, nature);
    }

    @Override
    public void affichage(Montre m) {
        System.out.println("********* MONTRE *********");
        System.out.println("ID : " + m.getId());
        System.out.println("Libell� : " + m.getLib());
        System.out.println("Nature : " + m.getNature());
    }
}