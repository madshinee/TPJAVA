public interface IArticle {
    Article saisie(); 
    void affichage(Article a); 
}
