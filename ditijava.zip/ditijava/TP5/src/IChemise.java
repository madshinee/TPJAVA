public interface IChemise {
    Chemise saisie(); 
    void affichage(Chemise c);
}
