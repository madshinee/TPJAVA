import java.util.Scanner;
import java.util.Random;

public class Etudiant extends Personne implements IPersonne {
    private String matricule;
    private double moyenne;
    private final Random random = new Random();


    public Etudiant() {
        super();
        this.matricule = generateMatricule();
        this.moyenne = 0.0;
    }

    public Etudiant(String nom, String prenom, double moyenne) {
        super(nom, prenom);
        this.matricule = generateMatricule();
        this.moyenne = moyenne;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public double getMoyenne() {
        return moyenne;
    }

    public void setMoyenne(double moyenne) {
        this.moyenne = moyenne;
    }

    
    private String generateMatricule() {
        return "MAT-" + random.nextInt(11); 
    }

    @Override
    public void saisie() {
        super.saisieP();
        Scanner sc = new Scanner(System.in);
        System.out.print("Entrer la moyenne : ");
        this.moyenne = sc.nextDouble();
        this.matricule = generateMatricule();
    }

    @Override
    public void affiche() {
        super.afficheP();
        System.out.println("*** Matricule: " + matricule);
        System.out.println("*** Moyenne: " + moyenne);
    }
}

