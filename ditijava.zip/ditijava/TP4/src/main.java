public class main {
    public static void main(String[] args) {
        System.out.println("********* ETUDIANT *********");
        Etudiant e = new Etudiant();
        e.saisie();
        e.affiche();
    	
    	System.out.println("********* EMPLOYE *********");
        Employe epl = new Employe();
        epl.saisie();
        epl.affiche();


    }
}
