public interface IPersonne {
    void saisie();
    void affiche();
}

