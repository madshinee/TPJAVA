import java.util.Scanner;

public class Employe extends Personne implements IPersonne {
    private String fonction;
    private int salaire;

    public Employe() {
        super();
        this.fonction = "";
        this.salaire = 0;
    }

    public Employe(String nom, String prenom, String fonction, int salaire) {
        super(nom, prenom);
        this.fonction = fonction;
        this.salaire = salaire;
    }

    public String getFonction() {
        return fonction;
    }

    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    public int getSalaire() {
        return salaire;
    }

    public void setSalaire(int salaire) {
        this.salaire = salaire;
    }

    @Override
    public void saisie() {
        super.saisieP();
        Scanner sc = new Scanner(System.in);
        System.out.print("Entrer la fonction : ");
        this.fonction = sc.nextLine();
        System.out.print("Entrer le salaire : ");
        this.salaire = sc.nextInt();
    }

    @Override
    public void affiche() {
        super.afficheP();
        System.out.println("*** Fonction: " + fonction);
        System.out.println("*** Salaire: " + salaire);
    }
}

