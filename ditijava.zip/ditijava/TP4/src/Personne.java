import java.util.Scanner;

public class Personne {
    private String nom;
    private String prenom;

    public Personne() {
        this.nom = "";
        this.prenom = "";
    }

    public Personne(String nom, String prenom) {
        this.nom = nom;
        this.prenom = prenom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void saisieP() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Entrez le nom : ");
        this.nom = sc.nextLine();
        System.out.print("Entrez le pr�nom : ");
        this.prenom = sc.nextLine();
    }
    
    public void afficheP() {
        System.out.println("*** Nom: " + nom );
        System.out.println("*** Pr�nom: " + prenom);

    }
}

