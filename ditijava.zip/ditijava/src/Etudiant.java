public class Etudiant {
    public final int MAX_NOTES = 10;
    private String nom;
    private String prenom;
    private int anneeNaissance;
    private double[] tabNotes;
    private int nbNotes; 
    private int ordre = 1;
    private String matricule;

    public Etudiant(String nom, String prenom) {
        this.nom = nom;
        this.prenom = prenom;
        this.anneeNaissance = anneeNaissance; 
        this.tabNotes = new double[MAX_NOTES];
        this.nbNotes = 0;
        this.matricule = genererMatricule(); 
    }

    public Etudiant(String nom, String prenom, int anneeNaissance) {
        this.nom = nom;
        this.prenom = prenom;
        this.anneeNaissance = anneeNaissance;
        this.tabNotes = new double[MAX_NOTES];
        this.nbNotes = 0;
        this.matricule = genererMatricule(); 
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public int getAnneeNaissance() {
        return anneeNaissance;
    }

    public void setAnneeNaissance(int anneeNaissance) {
        this.anneeNaissance = anneeNaissance;
    }
    
    public String getMatricule() {
        return matricule;
    }

    public double moyenne() {
        if (nbNotes == 0) return 0; 
        double somme = 0;
        for (int i = 0; i < nbNotes; i++) {
            somme += tabNotes[i];
        }
        return somme / nbNotes;
    }

    public double max() {
        if (nbNotes == 0) return 0; 
        double nMax = tabNotes[0];
        for (int i = 1; i < nbNotes; i++) {
            if (tabNotes[i] > nMax) {
            	nMax = tabNotes[i];
            }
        }
        return nMax;
    }

    public double min() {
        if (nbNotes == 0) return 0; 
        double nMin = tabNotes[0];
        for (int i = 1; i < nbNotes; i++) {
            if (tabNotes[i] < nMin) {
            	nMin = tabNotes[i];
            }
        }
        return nMin;
    }

    public void ajouterNote(double note) {
        if (nbNotes < MAX_NOTES) {
            tabNotes[nbNotes] = note;
            System.out.println("Note " + (nbNotes + 1) + " = " + note);
            nbNotes++;
        } else {
            System.out.println("Le tableau de notes est plein.");
        }
    }


    public int age() {
        int anneeActuelle = java.time.Year.now().getValue();
        return anneeActuelle - anneeNaissance;
    }

    @Override
    public String toString() {
        return "�tudiant [Nom: " + nom + ", Pr�nom: " + prenom + ", �ge: " + age() + "]";
    }

    private String genererMatricule() {
        String mat;
        mat = "Mat-" + this.nom.charAt(0) + this.prenom.charAt(0) + ordre;
        ordre++;
        return mat;
    }
}








