public class main {
    public static void main(String[] args) {

        Etudiant e1 = new Etudiant("Sow", "Dieynaba");
        Etudiant e2 = new Etudiant("Sarr", "Babacar", 2009);

        System.out.println("********* Infos de Etudiant 1 *********");
        System.out.println("Nom : " + e1.getNom());
        System.out.println("Pr�nom : " + e1.getPrenom());
        System.out.println("Ann�e de naissance : " + e1.getAnneeNaissance());
        System.out.println("Age : " + e1.age());
        System.out.println("Matricule : " + e1.getMatricule());
        System.out.println("\n         Notes de " + e1.getPrenom() + " " + e1.getNom());
        e1.ajouterNote(12);
        e1.ajouterNote(15);
        e1.ajouterNote(18);
        System.out.println("Meilleure note = " + e1.max());
        System.out.println("Note la plus faible = " + e1.min());
        System.out.println("MOYENNE = " + e1.moyenne());


        System.out.println("********* Infos de Etudiant 2 *********");
        System.out.println("Nom : " + e2.getNom());
        System.out.println("Pr�nom : " + e2.getPrenom());
        System.out.println("Ann�e de naissance : " + e2.getAnneeNaissance());
        System.out.println("Age : " + e2.age());
        System.out.println("Matricule : " + e2.getMatricule());
        System.out.println("\n         Notes de " + e2.getPrenom() + " " + e2.getNom());
        e2.ajouterNote(13);
        e2.ajouterNote(16);
        e2.ajouterNote(19);
        System.out.println("Meilleure note = " + e2.max());
        System.out.println("Note la plus faible = " + e2.min());
        System.out.println("MOYENNE = " + e2.moyenne());


        if (e1.age() > e2.age()) {
            System.out.println("\n" + e1.getPrenom() + " " + e1.getNom() + " est plus vieux");
        } else if (e1.age() < e2.age()) {
            System.out.println("\n" + e1.getPrenom() + " " + e1.getNom() + " est plus jeune");
        } else {
            System.out.println("\n" + e1.getPrenom() + " " + e1.getNom() + " et " + e2.getPrenom() + " " + e2.getNom() + " ont le m�me �ge");
        }






    }
}


